Example gallery
===============

Below is a gallery of examples on how to use `hazardous` for predictive
competive risk analysis problems.
