:mod:`{{module}}`.{{objname}}
{{ underline }}==============

.. rst-class:: side_comment

    Usage examples at the bottom of this page.

.. currentmodule:: {{ module }}

.. autoclass:: {{ objname }}
   :inherited-members:

   {% block methods %}

   {% endblock %}

.. raw:: html

    <div class="clearer"></div>
