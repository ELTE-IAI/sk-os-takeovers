.. _cluster_examples:

Hierarchical Clustering and NCO
-------------------------------

Examples concerning hierarchical clustering based optimizations.
