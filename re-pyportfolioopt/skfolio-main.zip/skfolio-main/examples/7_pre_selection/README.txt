.. _pre_selection_examples:

Pre-selection
-------------

Examples of using :ref:`pre-selection transformers <pre_selection>` with `Pipelines`.


