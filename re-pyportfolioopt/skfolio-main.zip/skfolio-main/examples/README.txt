.. _general_examples:

Examples
========

We recommend starting with :ref:`sphx_glr_auto_examples_1_mean_risk_plot_1_maximum_sharpe_ratio.py`
or :ref:`sphx_glr_auto_examples_1_mean_risk_plot_2_minimum_CVaR.py` before moving to more advanced examples.


