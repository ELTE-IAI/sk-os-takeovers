.. _mean_risk_examples:

Mean-Risk
---------

Examples using the :class:`~skfolio.optimization.MeanRisk` optimization.

