.. _maximum_diversification_examples:

Maximum Diversification
-----------------------

Examples concerning the :class:`~skfolio.optimization.MaximumDiversification` optimization.

