.. _risk_budgeting_examples:

Risk Budgeting
--------------

Examples concerning the :class:`~skfolio.optimization.RiskBudgeting` optimization.

