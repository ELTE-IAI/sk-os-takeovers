.. _distributionally_robust_examples:

Distributionally Robust CVaR
----------------------------

Examples concerning the :class:`~skfolio.optimization.DistributionallyRobustCVaR` optimization.

