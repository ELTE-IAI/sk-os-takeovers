************
Installation
************

``skfolio`` is available on PyPI and can be installed with:

.. code:: console

    $ pip install skfolio
